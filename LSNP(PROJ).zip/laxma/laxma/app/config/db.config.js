module.exports = {
    HOST : "localhost",
    USER : "root",
    PASSWORD : "laxma@123",
    DB:"restaurant"
};