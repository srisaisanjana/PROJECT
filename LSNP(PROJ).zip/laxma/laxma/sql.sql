create database restaurant;
use restaurant;
 
create table customers(
        Id int auto_increment,
        Name varchar(50) not null,
		Email varchar(50) not null,
        Feedback varchar(5000) not null,
        primary key(Id)
);

select * from customers;

create table bookings(
        Id int auto_increment,
        Name varchar(50) not null,
		Email varchar(50) not null,
        Number bigint not null,
        primary key(Id)
);

select * from bookings;